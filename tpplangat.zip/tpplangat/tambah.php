<?php
include "config.php";

if (isset($_POST['submit'])){
      $id=$_POST['id'];
      $no_ndp=$_POST['no_ndp'];
      $nama_pelajar=$_POST['nama_pelajar'];
      $no_kp=$_POST['no_kp'];
      $jantina=$_POST['jantina'];
      $no_hp=$_POST['no_hp'];
      
    $sql="insert into `info_pelajar`(id,no_ndp,nama_pelajar,no_kp,jantina,no_hp) values('$id','$no_ndp','$nama_pelajar','$no_kp','$jantina','$no_hp')";
    $result=mysqli_query($con,$sql);
    if($result){
        // echo "Data dimasukkan berjaya";
        header('location:halaman.php');
    }else{
     die(mysqli_error($con));
    }
} 
?>

<!--HTML Bermula -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SISTEM MAKLUMAT PELAJAR</title>
    <link rel="stylesheet" href = "https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
</head>

<body>
   <div class="container my-6">
    <form method="post">

    <div class="form-group">
         <label>Id</label>
         <input type="text" class="form-control" 
         placeholder="Sila isi nombor id anda" name="id" autocomplete="off">       
    </div>

    <div class="form-group">
         <label>No Ndp</label>
         <input type="text" class="form-control" 
         placeholder="Sila isi nombor ndp anda" name="nama_pengguna" autocomplete="off">       
    </div>

    <div class="form-group">
         <label>Nama Pelajar</label>
         <input type="text" class="form-control" 
         placeholder="Sila isi nama anda" name="nama_pengguna" autocomplete="off">       
    </div>


    <div class="form-group">
         <label>No Kad Pengenalan</label>
         <input type="text" class="form-control" 
         placeholder="Sila isi nombor kad pengenalan anda" name="no_kp" autocomplete="off">        
    </div>

        <div class="form-group">
         <label>Jantina</label>
         <input type="text" class="form-control" 
         placeholder="Sila isi jantina anda" name="jantina" autocomplete="off">        
    </div>

    <div class="form-group">
         <label>No Telefon</label>
         <input type="text" class="form-control" 
         placeholder="Sila isi nombor telefon anda" name="no_hp" autocomplete="off">   
    </div>


    <button type="submit" 
            class="btn btn-primary"
            name="submit">Submit</button>
    </form>
  </div>
</body>

</html>