<?php
include 'config.php';?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SISTEM MAKLUMAT PELAJAR</title>
    <link rel="stylesheet" href = "https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
</head>

<body>
<div class="container">
  <div class="row mt-4">
    <div class="col-lg-12 d-flex justify-content-between align-itemscenter">
     <h4 class="text text-center text-striped">SISTEM MAKLUMAT PELAJAR</h4>
 </div>

<div>
    <button class="btn btn-primary my-5"><a href="tambah.php" class="text-light"type="button" data-toggle="modal"data-target="#addNewUserModal">Tambah Pelajar</a></button>

    <table class="table table-striped table-bordered text-center">
         <thead>
             <tr>
               <th scope="col">id</th>
               <th scope="col">nama_pelajar</th>
               <th scope="col">no_ndp</th>
               <th scope="col">no_kp</th>
               <th scope="col">no_hp</th>
               <th scope="col">jantina</th>
        
             </tr>
         </thead>

  <tbody>

  <?php  
  
  $sql = "SELECT * FROM `info_pelajar`";
  $result=mysqli_query($con,$sql);
  if($result){
    while($row=mysqli_fetch_assoc($result)){
      $id=$row['id'];
      $no_ndp=$row['no_ndp'];
      $nama_pelajar=$row['nama_pelajar'];
      $no_kp=$row['no_kp'];
      $no_hp=$row['no_hp'];
      $jantina=$row['jantina'];
      
      echo '<tr>
      <th scope="row">'.$id.'</th>
      <td>'.$nama_pelajar.'</td>
      <td>'.$no_ndp.'</td>
      <td>'.$no_kp.'</td>
     <td>'.$no_hp.'</td>
      <td>'.$jantina.'</td>
      
     <td>
        <button class="btn btn-primary"><a href="update.php?updateid='.$id.'" class="text-light">Kemaskini</a></button>
        <button class="btn btn-danger"><a href="delete.php?deleteid='.$id.'" class="text-light">Padam</a></button>
     </td>
    </tr>';
    }
 }
  ?>
  </tbody>

   </table>
</div>
</body>

</html>