<?php

$con=new mysqli('localhost','root','','datapelajar');

if(!$con){
    die(mysqli_error($con));
}

?>