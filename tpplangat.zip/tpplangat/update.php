<?php
include "config.php";
$id=$_GET['updateid'];
$sql="Select * from `info_pelajar` where id=$id";
$result=mysqli_query($con,$sql);
$row=mysqli_fetch_assoc($result);
$id=$row['id'];
$no_ndp=$row['no_ndp'];
$nama_pelajar=$row['nama_pelajar'];
$no_kp=$row['no_kp'];
$no_hp=$row['no_hp'];
$jantina=$row['jantina'];

if (isset($_POST['submit'])){
      $id=$_POST['id'];
      $no_ndp=$_POST['no_ndp'];
      $nama_pelajar=$_POST['nama_pelajar'];
      $no_kp=$_POST['no_kp'];
      $no_hp=$_POST['no_hp'];
      $jantina=$_POST['jantina'];

      $sql="update `info_pelajar` set id=$id, no_ndp='$no_ndp', nama_pelajar='$nama_pelajar',no_kp='$no_kp', no_hp='$no_hp', jantina='$jantina' where id=$id";
      $result=mysqli_query($con,$sql);
      if($result){
        // echo "kemaskini berjaya";
        header('location:halaman.php');
      }else{
      die(mysqli_error($con));
      }
} 

?>

<!--HTML Bermula -->

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SISTEM MAKLUMAT PELAJAR TPP </title>
    <link rel="stylesheet" href = "https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
</head>

<body>
   <div class="container my-6">
    <form method="post">

    <div class="form-group">
         <label>id</label>
         <input type="text" class="form-control" 
         placeholder="Sila isi nombor id anda" name="id" autocomplete="off" value=<?php
         echo $id;?>>       
    </div>

    <div class="form-group">
         <label>ndp</label>
         <input type="text" class="form-control" 
         placeholder="Sila isi ndp anda" name="no_ndp" autocomplete="off" value=<?php
         echo $no_ndp;?>>
    </div>

    <div class="form-group">
         <label>Nama</label>
         <input type="text" class="form-control" 
         placeholder="Sila isi nama anda" name="nama_pelajar" autocomplete="off" value=<?php
         echo $nama_pelajar;?>>
    </div>

    <div class="form-group">
         <label>No Kp</label>
         <input type="text" class="form-control" 
         placeholder="Sila isi nombor kad pengenalan anda" name="no_kp" autocomplete="off" value=<?php echo $no_kp;?>>        
    </div>

    <div class="form-group">
         <label>No Hp</label>
         <input type="text" class="form-control" 
         placeholder="Sila isi nombor telefon anda" name="no_hp" autocomplete="off" value=<?php echo $no_hp;?>>   
    </div>

    <div class="form-group">
         <label>Jantina</label>
         <input type="text" class="form-control" 
         placeholder="Sila isi jantina anda" name="jantina" autocomplete="off" value=<?php echo $jantina;?>>        
    </div>

    <button type="submit" 
            class="btn btn-primary"
            name="submit">Kemaskini</button>
    </form>
  </div>


</body>

</html>